﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shield_script : MonoBehaviour {
    private float max_show_Time=3;//最大显示时间
    private float vailTime;//计时变量
  
    void Update() {
        vailTime += Time.deltaTime;//计时器
        //到时间就设为隐藏
        if (vailTime >= max_show_Time) {
            this.gameObject.SetActive(false);
            max_show_Time = 10f;//为下一次碰撞防护罩，设为10秒 
        }

    }
    /// <summary>
    /// 可能会出现二次碰撞
    /// </summary>
    public void setTimeNow()
    {
        vailTime = 0;
        max_show_Time = 10f;
    }
}
