﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Home_an : MonoBehaviour {
    //---基地类--
    public Sprite sprites;
    private SpriteRenderer tempRenderer;
	void Start () {
        //取得精灵图片组件
        tempRenderer = GetComponent<SpriteRenderer>();
	}


    void OnCollisionEnter2D(Collision2D Other) {
        //加载另一精灵图片组件
        tempRenderer.sprite = sprites;
        EnemyIconCode._enemyIconScript.setGameOver();//上升GameOver字幕
        ManageClass.IS_GAMEOVER = true;
       
    }

    void OnTriggerEnter2D(Collider2D Other)
    {
        //加载另一精灵图片组件
        tempRenderer.sprite = sprites;
        EnemyIconCode._enemyIconScript.setGameOver();
        ManageClass.IS_GAMEOVER = true;
        
    }


   
}
