﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class showTime : MonoBehaviour {

	
	void Start () {
        Invoke("showTime22",3f);
	}
    void showTime22() {
        SceneManager.LoadScene(0);
    }
}
