﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class EnemyControl : MonoBehaviour {
    private Animator an;
    private Rigidbody2D rb;
    private  GameObject buttlet_object;
    private bool IS_Create_Bullet = true; //是否能发射子弹，因为敌机只能发射一个子弹

    private float speed = 3f;
    private float h;
    private float v = -1;
    private float changRotationTime;
    private float maxTime;
    private int HP=1;
    private GameObject  Big_Boom_Object;
    public enum enemyTypeEnum
    {
        EnemyTypeA = 0,
        EnemyTypeB = 1,
        EnemyTypeC = 2,
        EnemyTypeD = 3
    }
    public enemyTypeEnum EnemyType22;

    void Start()
    {
        an = this.GetComponent<Animator>();
        buttlet_object = (GameObject)Resources.Load("enemyBullet");//加载一个子弹 
        InvokeRepeating("Fire", 0f, 1f); //发射子弹时间
        maxTime = Random.Range(0.5f,2f);//产生最大转身时间
        rb = GetComponent<Rigidbody2D>();
        Big_Boom_Object = (GameObject)Resources.Load("Block/Boom/Big_Boom");
        switch (EnemyType22) { 
            case enemyTypeEnum.EnemyTypeB:
                //如果是B敌机速度加快
                speed=5f;
                break;
        }
    }
    


    void FixedUpdate()
    { 
        //-----------当碰撞了，定时炸弹-------------
        if(ManageClass.IS_Collider_StopBoom==true){
            an.SetInteger("IS_RUN", 0);//设置静止状态动画
            return;
        }

        Move();
       
     
    }//update

    //主角移动
    private void Move()
    {   //到时间旋转
        if (changRotationTime >= maxTime)
        {
            int num = Random.Range(0, 8);//产生转身方向，随机数
            if (num > 5)
            {
                v = -1;
                h = 0;
            }
            else if (num == 0)
            {
                v = 1;
                h = 0;
            }
            else if (num > 0 && num <= 2)
            {
                h = -1;
                v = 0;
            }
            else if (num > 2 && num <= 4)
            {
                h = 1;
                v = 0;
            }

            changRotationTime = 0;//重置转身时间
            maxTime = Random.Range(0.5f, 2f);//产生最大转身时间


        }
        else {
            changRotationTime += Time.fixedDeltaTime;//计时器
        
        }
        EnemyState(); //动画状态
        //竖
      //  transform.Translate(Vector3.up * v * speed * Time.fixedDeltaTime, Space.World);
        PlayRotation();
        transform.Translate(transform.up.normalized * Mathf.Abs(v) * speed * Time.fixedDeltaTime, Space.World);

        if (v != 0) { return; }//-----------------------------
        //横
     //   transform.Translate(Vector3.right * h * speed * Time.fixedDeltaTime, Space.World);
        PlayRotation();
        transform.Translate(transform.up.normalized * Mathf.Abs(h) * speed * Time.fixedDeltaTime, Space.World);
    }

    //动画状态
    private void EnemyState()
    {

        if (HP < 5 && EnemyType22 == enemyTypeEnum.EnemyTypeD )
        {
            an.SetInteger("HP", HP);
        }        

        if (h != 0 || v != 0)
        {
            an.SetInteger("IS_RUN", 1);
        }
        else
        {
            an.SetInteger("IS_RUN", 0);
        }
    }

    //坦克转向
    private void PlayRotation()
    {
        if (v > 0)
        {  //上
            transform.rotation = Quaternion.identity;

        }
        else if (v < 0)
        {
            transform.rotation = Quaternion.Euler(0, 0, -180);

        }
        if (v != 0)
        {
            return;

        }
        if (h > 0)
        {
            //右
            transform.rotation = Quaternion.Euler(0, 0, -90);

        }
        else if (h < 0)
        {
            transform.rotation = Quaternion.Euler(0, 0, 90);

        }
    }

    //发射子弹 
    private void Fire()
    {
        //-----------当碰撞了，定时炸弹-------------
        if (ManageClass.IS_Collider_StopBoom == true) { return; }


        //如果敌机已生成了子弹就不能再生成了
        if (IS_Create_Bullet == false) { return; }
 
             //生成一个敌机子弹
        GameObject tempEnemyObject = (GameObject)Instantiate(buttlet_object, transform.position, Quaternion.Euler(transform.eulerAngles));
        tempEnemyObject.GetComponent<Bullet_Move>().enemy_object = this.gameObject;//将这个敌机对象，引入到子弹类，为了更新敌机，当前拥有子弹数
        IS_Create_Bullet = false; //关闭制造子弹
    }

    //碰撞方法
    private void OnCollisionEnter2D(Collision2D collision)
    {
      
      //当与敌机或者主角碰撞时，就开启不受重力影响
        if (collision.gameObject.tag == "enemy" )
        {
           rb.bodyType = RigidbodyType2D.Kinematic;//开启不受重力影响
            changRotationTime = maxTime;
        }
        if (collision.gameObject.tag == "Player")
        {
            changRotationTime = maxTime;

        }
       
    }

    void OnCollisionExit2D(Collision2D Other) {

        if (Other.gameObject.tag == "enemy" )
        {
            rb.bodyType = RigidbodyType2D.Dynamic;//开启不受重力影响
        }
    
    }
    //是否能发射子弹，因为敌机只能发射一个子弹
   public void setCreateBulllet() {
       IS_Create_Bullet = true;
    }


   public void Die() { 


       //加分数
    switch(EnemyType22){
        case enemyTypeEnum.EnemyTypeA:
            ManageClass.enemyTypeCount_A += 1;
            EnemyIconCode._enemyIconScript.setDelEnemyScore(100, this.transform);
            Destroy(this.gameObject);
             Instantiate(Big_Boom_Object, this.transform.position, Quaternion.identity);//加入boom
            break;
        case enemyTypeEnum.EnemyTypeB:
            ManageClass.enemyTypeCount_B += 1;
            EnemyIconCode._enemyIconScript.setDelEnemyScore(200, this.transform);
            Destroy(this.gameObject);
             Instantiate(Big_Boom_Object, this.transform.position, Quaternion.identity);//加入boom
            break;
        case enemyTypeEnum.EnemyTypeC:
            ManageClass.enemyTypeCount_C += 1;
            EnemyIconCode._enemyIconScript.setDelEnemyScore(300, this.transform);
            Destroy(this.gameObject);
            Instantiate(Big_Boom_Object, this.transform.position, Quaternion.identity);//加入boom
            break;
        case enemyTypeEnum.EnemyTypeD:
            HP += 1;

            if (HP > 4)
            {
                //如果已中四个子弹就DIE
                ManageClass.enemyTypeCount_D += 1;
                EnemyIconCode._enemyIconScript.setDelEnemyScore(500, this.transform);
                Destroy(this.gameObject);
                Instantiate(Big_Boom_Object, this.transform.position, Quaternion.identity);//加入boom
            }
            else { 
            
            
            }

            break;
    
    }
   
   }


   


  // public void Rest_changRotationTime() {
  //changRotationTime = maxTime;
  // }

}//class
