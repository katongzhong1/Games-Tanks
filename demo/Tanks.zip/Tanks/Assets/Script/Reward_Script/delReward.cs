﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class delReward : MonoBehaviour {

	
	void Start () {
        Destroy(this.gameObject, 10f);
	}
   
	
}
