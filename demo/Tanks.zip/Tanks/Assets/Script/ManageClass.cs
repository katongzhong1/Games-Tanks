﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static  class ManageClass{
    public static int LeveCount = 1; //关数
    public static int MaxLeveCount = 2;//max关数

    public static int OutTakeCount = 3;//将要生成敌机数量
    public static int PlayerCount = 2;//主角机数

	public static List<GameObject> Take_List = new List<GameObject>(); //敌机将要出场机的泛型
    public static bool IS_GAMEOVER; //是否游戏结束

    public static int playerScore=0; //主角分数
    public static int heightScore = 20000; //最高分数

    public static bool IS_Collider_StopBoom;//是不是碰撞了，定时炸弹
    public static int PlayerLV = 1;//主角级数


    //敌机类型数量
    public static int enemyTypeCount_A=0;
    public static int enemyTypeCount_B = 0;
    public static int enemyTypeCount_C = 0;
    public static int enemyTypeCount_D = 0;
   
    //重置游戏选项
  public static void restGame(){
        LeveCount = 1;
        OutTakeCount=3;
        PlayerCount = 2;
        Take_List.Clear();
        IS_GAMEOVER = false;
        playerScore = 0;
        IS_Collider_StopBoom = false;
        PlayerLV = 1;
        enemyTypeCount_A=0;
        enemyTypeCount_B=0;
        enemyTypeCount_C=0;
        enemyTypeCount_D=0;
    }
    //进关设置
  public static void nextLeveSet() {
      enemyTypeCount_A = 0;
      enemyTypeCount_B = 0;
      enemyTypeCount_C = 0;
      enemyTypeCount_D = 0;
      IS_Collider_StopBoom = false;
      OutTakeCount = 3;
      Take_List.Clear();
      IS_Collider_StopBoom = false;
  }
	
}
