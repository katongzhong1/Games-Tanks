﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneP1Move : MonoBehaviour {

    public Transform one_point, two_point, three_point;
    private int Count;

	void Start () {
		
	}
	
	
	void Update () {

		if(Input.GetKeyDown(KeyCode.S)){
            if (Count < 2)
            {
                Count += 1;
            }
            else {
                Count = 0;
            }
           
        }
        switch (Count) {
            case 0:
                this.transform.position = one_point.transform.position;
                break;
            case 1 :
                 this.transform.position = two_point.transform.position;
                break;

            case 2 :
                this.transform.position = three_point.transform.position;
                break;
        
        }

        if (Input.GetKeyDown(KeyCode.Space) && Count ==0)
        {
            SceneManager.LoadScene(1);
        }

	}
}
