﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score_get : MonoBehaviour {

    private bool IS_ZERO;
    private GameObject P1_Object;
	void Start () {
        //主角分数
        if (ManageClass.playerScore == 0)
        {
            this.transform.GetChild(0).GetComponent<Text>().text ="00  ";
        }
        else {
            this.transform.GetChild(0).GetComponent<Text>().text = ManageClass.playerScore + "";
        }
        //最高分数
        this.transform.GetChild(1).GetComponent<Text>().text = ManageClass.heightScore + "";

        P1_Object = (GameObject)Resources.Load("ScoreSence/Take_object_ScoreSence"); //加载坦克
	}

    void Update() {
        if (IS_ZERO == true) { return; }
        //当按下任意键时，背景上升到最上处
        if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.Space))
        {
            this.gameObject.GetComponent<RectTransform>().localPosition = Vector3.zero; //设置背景的坐标为原点
            IS_ZERO = true;
            Instantiate(P1_Object);//生成坦克
            return;
        }
        if (this.gameObject.GetComponent<RectTransform>().localPosition.y < 0)
        {
            this.gameObject.GetComponent<RectTransform>().localPosition += new Vector3(0, 8f, 0);
        }
        else {
            IS_ZERO = true;
            this.gameObject.GetComponent<RectTransform>().localPosition = Vector3.zero;
            Instantiate(P1_Object);//生成坦克

        }
       
      
    }
	
}
