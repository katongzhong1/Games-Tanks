﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour {
	private  float speed=3f;
	private float v = 0;
	private float h = 0;

	private Animator an;
    private GameObject buttlet_object; //子弹对象
    public int LV = 1; //主机级数
    private int maxButtletCount = 1;//最大可发射弹数
    public int nowButtletCount = 0;//现在子弹数
    private Rigidbody2D rb;


	void Start () {
        rb = GetComponent<Rigidbody2D>();
		an = GetComponent<Animator> ();
          buttlet_object = (GameObject)Resources.Load("bullet");
          LV = ManageClass.PlayerLV;
        
	}
	

	void FixedUpdate () {
        if(ManageClass.IS_GAMEOVER==true){return;}
        Move();
      //  PlayRotation();
        playerState();
      
	}
    void Update() {
        if (ManageClass.IS_GAMEOVER == true) { return; }
        Fire();
    }
    //主角移动
	private void Move(){
		//竖
	
		v= Input.GetAxisRaw ("Vertical");
      //  transform.Translate(Vector3.up * v * speed * Time.fixedDeltaTime,Space.World);
        PlayRotation();
        transform.Translate(transform.up.normalized * Mathf.Abs(v) * speed * Time.fixedDeltaTime, Space.World);
        if (v != 0) { return; }
        
		//横
		h = Input.GetAxisRaw ("Horizontal");
     //   transform.Translate(Vector3.right * h * speed * Time.fixedDeltaTime, Space.World);
        PlayRotation();
        transform.Translate(transform.up.normalized * Mathf.Abs(h) * speed * Time.fixedDeltaTime, Space.World);

       
	}
	//动画状态
	private void playerState(){
		if (h != 0 || v != 0) {
			an.SetInteger ("IS_RUN", 1);
		} else {
			an.SetInteger ("IS_RUN", 0);
		}
	}
	//坦克转向
	private void PlayRotation(){
		if(v>0){  //上
			transform.rotation = Quaternion.identity;
           
		}else if (v<0){
			transform.rotation = Quaternion.Euler (0, 0, -180);
           
		}
		if (v != 0) {
			return;

		}
		if(h>0){
            //右
			transform.rotation =Quaternion.Euler (0, 0, -90);
            
		}else if (h<0){
			transform.rotation = Quaternion.Euler (0, 0, 90);
           
		}
	}
    //发射子弹 
    private void Fire() {
        if (nowButtletCount >= maxButtletCount) { return; } //如果现在子弹数，大于最大子弹数就不能发射
        if (Input.GetKeyDown(KeyCode.Space) )
        {
            nowButtletCount += 1; //现在子弹数加一
            Instantiate(buttlet_object, transform.position, Quaternion.Euler(transform.eulerAngles ));//在场景中生成一个子弹
        }
    }


    /// <summary>
    /// 碰撞检测
    /// </summary>
    /// <param name="Other"></param>
    void OnTriggerEnter2D(Collider2D Other)
    {  //奖励品
        switch (Other.gameObject.tag)
        {
              case "add_p1_tag":
                //---------加一个主机-------------
                Destroy(Other.gameObject);
                ManageClass.PlayerCount += 1;
                EnemyIconCode._enemyIconScript.setPlayerCount();//更新显示主机数量
                  break;

              case "shield_tag":
                  //-------防护罩----------
                  this.transform.GetChild(0).gameObject.SetActive(true);
                  this.transform.GetChild(0).gameObject.SendMessage("setTimeNow");
                  Destroy(Other.gameObject);
                  break;

            case "stop_Boom_tag":
                //---------定时炸弹-----
                  ManageClass.IS_Collider_StopBoom = true;//定时炸弹碰撞了
                  Invoke("enemy_move_true",10f);
                  Destroy(Other.gameObject);
                  break;

            case "Boom_bomb_tag":
                //---------炸弹BOOM-------
                   GameObject tmepAllEnemyArry = GameObject.FindGameObjectWithTag("allEnemyTag"); //取得敌机父的对象
                  Destroy(Other.gameObject); 
                  //-----------偏历所有敌机------------
                  for (var i = 0; i < tmepAllEnemyArry.transform.childCount; i++)
                  {
                      Destroy(tmepAllEnemyArry.transform.GetChild(i).gameObject); //删除场景上的全部敌机
                     tmepAllEnemyArry.transform.GetChild(i).gameObject.SendMessage("Die"); //调用敌机的死亡方法
                      ManageClass.OutTakeCount += 1; //将要出场敌机数加1
                  }
                  break;


            case  "starts_tag":
                  //---------星星-------
                    Destroy(Other.gameObject);
                    if(LV<4){
                        LV += 1; //级数加1
                        ManageClass.PlayerLV += 1;
                        an.SetInteger("HP", LV);
                    }
                
                  break;
               
          }



    }

    /// <summary>
    /// 定时炸弹碰撞了，10秒后设敌机可运动
    /// </summary>
    void enemy_move_true() {
        ManageClass.IS_Collider_StopBoom = false;
    }

    //如果主角是4级与子弹碰撞，那么就下落到1级
    public void setLV() {
        LV = 1; //级数加1
        ManageClass.PlayerLV = 1;
        an.SetInteger("HP", LV);
    }


    //void OnCollisionStay2D(Collision2D Other)
    //{        //如果敌机的运动方向是正对主角，那么改变方向                                      
    //    if (Other.gameObject.tag == "enemy" && Other.contacts[0].normal == Vector2.up)
    //    {
    //        Other.gameObject.SendMessage("Rest_changRotationTime");
    //    }
    //    else if (Other.gameObject.tag == "enemy" && Other.contacts[0].normal == Vector2.down)
    //    {
    //        Other.gameObject.SendMessage("Rest_changRotationTime");
    //    }
    //    else if (Other.gameObject.tag == "enemy" && Other.contacts[0].normal == Vector2.left)
    //    {
    //        Other.gameObject.SendMessage("Rest_changRotationTime");
    //    }
    //    else if (Other.gameObject.tag == "enemy" && Other.contacts[0].normal == Vector2.right)
    //    {
    //        Other.gameObject.SendMessage("Rest_changRotationTime");
    //    }
    //}
 

   




}//class
