﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateMap : MonoBehaviour {
	//private GameObject bound_object;//边界
    private GameObject Brick_object ,Grass_object,Grid_object,Water_object,BG,home_object;//完整个砖块对象

    //二块小砖
    private GameObject Brick_1100, Brick_0011, Brick_1010, Brick_0101;
    private GameObject Grid_1100, Grid_0011, Grid_1010, Grid_0101;
    //一块小砖
    private GameObject Brick_0010, Brick_0001;
    public GameObject all_block;
	private int[,,] map ={{
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0},
        {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0},
        {0, 1, 0, 1, 0, 1, 2, 1, 0, 1, 0, 1, 0},
        {0, 1, 0, 1, 0, 6, 0, 6, 0, 1, 0, 1, 0},
        {0, 6, 0, 6, 0, 5, 0, 5, 0, 6, 0, 6, 0},
        {5, 0, 5, 5, 0, 6, 0, 6, 0, 5, 5, 0, 5},
        {10, 0, 6, 6, 0, 5, 0, 5, 0, 6, 6, 0, 10},
        {0, 5, 0, 5, 0, 1, 1, 1, 0, 5, 0, 5, 0},
        {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0},
        {0, 1, 0, 1, 0, 6, 0, 6, 0, 1, 0, 1, 0},
        {0, 1, 0, 1, 0, 14, 5, 13, 0, 1, 0, 1, 0},
        {0, 0, 0, 0, 0, 7, 15, 8, 0, 0, 0, 0, 0}
        
 },{    {0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0},
        {0, 1, 0, 2, 0, 0, 0, 1, 0, 1, 0, 1, 0},
        {0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 2, 1, 0},
        {0, 0, 0, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0},
        {4, 0, 0, 1, 0, 0, 2, 0, 0, 1, 4, 1, 2},
        {4, 4, 0, 0, 0, 1, 0, 0, 2, 0, 4, 0, 0},
        {0, 1, 1, 1, 4, 4, 4, 2, 0, 0, 4, 1, 0},
        {0, 0, 0, 2, 4, 1, 0, 1, 0, 1, 0, 1, 0},
        {2, 1, 0, 2, 0, 1, 0, 1, 0, 0, 0, 1, 0},
        {0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 2, 1, 0},
        {0, 1, 0, 1, 0, 6, 1, 6, 0, 0, 0, 0, 0},
        {0, 1, 0, 0, 0, 14, 5, 13, 0, 1, 0, 1, 0},
        {0, 1, 0, 1, 0, 7, 15, 8, 0, 1, 1, 1, 0}
   
   }};

    //1红砖 2钻石砖 3河流 4树林
    private void Awake()
    {
        
        //生成背景图片
        BG = (GameObject)Resources.Load("Block/bg11");
        Instantiate(BG); //加载背景图片，游戏内
		//生成边界
        //bound_object = (GameObject)Resources.Load("Block/Bounds");
		//Instantiate (bound_object); //加载边界到，游戏内

        //生成基地
        home_object = (GameObject)Resources.Load("Other/home");
       

	    //生成砖块
        Brick_object = (GameObject)Resources.Load("Block/Brick");
        Grass_object = (GameObject)Resources.Load("Block/Grass");
        Grid_object = (GameObject)Resources.Load("Block/Grid");
        Water_object = (GameObject)Resources.Load("Block/Water");

        //生成半角红砖对象0011 1100 0101 1010
        Brick_0011=  (GameObject)Resources.Load("Block/Half_Wall/Brick0011");//5
        Brick_1100 = (GameObject)Resources.Load("Block/Half_Wall/Brick1100");//6
        Brick_0101 = (GameObject)Resources.Load("Block/Half_Wall/Brick0101");//7
        Brick_1010 = (GameObject)Resources.Load("Block/Half_Wall/Brick1010");//8

        //生成半角钻石砖对象0011 1100 0101 1010
        Grid_0011 = (GameObject)Resources.Load("Block/Half_Wall/Grid0011");//9
        Grid_1100 = (GameObject)Resources.Load("Block/Half_Wall/Grid1100");//10
        Grid_0101 = (GameObject)Resources.Load("Block/Half_Wall/Grid0101");//11
        Grid_1010 = (GameObject)Resources.Load("Block/Half_Wall/Grid1010");//12

        //生成一小块红砖                                
        Brick_0010 = (GameObject)Resources.Load("Block/Half_Wall/one_pic/Brick0010");//13
        Brick_0001 = (GameObject)Resources.Load("Block/Half_Wall/one_pic/Brick0001");//14

        craeteMap();
       

     //   Vector3 temp_p = new Vector3(-6f ,4.5f, 0);
        //Instantiate(Brick_object, temp_p, Quaternion.identity);

	}





    //left x=-6  y=4.5  right x= 5.5 y=4.5

	private void craeteMap(){
        int z = ManageClass.LeveCount - 1;//当前关数
        for (var i = 0; i < 13; i++) {
            for (var j = 0; j < 13; j++) {
                style_wall(map[z,i, j], i, j); //判断是什么类型，加载砖块
            }
        }
        
}

    //---加载砖块方法--
    private void style_wall(int NumCount,int i,int j) {

        switch (NumCount)
        {
                
            case 1:
                //红砖
                wall_position(Brick_object, i, j);
                break;

            case 2:
                //钻石砖
                wall_position(Grid_object, i, j);
                break;
            case 3:
                //河流
                wall_position(Water_object, i, j);
                break;
            case 4:
                //树林
                wall_position(Grass_object, i, j);
                break;

            case 5:
                //-----------生成半角红砖对象0011 1100 0101 1010--------------------
                wall_position(Brick_0011, i, j);
                break;
            case 6:
                // //生成半角红砖对象0011 1100 0101 1010
                wall_position(Brick_1100, i, j);
                break;
            case 7:
                // //生成半角红砖对象0011 1100 0101 1010
                wall_position(Brick_0101, i, j);
                break;
            case 8:
                // //生成半角红砖对象0011 1100 0101 1010
                wall_position(Brick_1010, i, j);
                break;
            case 9:
                // ----------生成半角钻石砖对象0011 1100 0101 1010----------
                wall_position(Grid_0011, i, j);
                break;
            case 10:
                // //生成半角钻石砖对象1100 
                wall_position(Grid_1100, i, j);
                break;
            case 11:
                // //生成半角钻石砖对象0101
                wall_position(Grid_0101, i, j);
                break;
            case 12:
                // //生成半角钻石砖对象1010
                wall_position(Grid_1010, i, j);
                break;

            case 13:
                // //生成一块红砖砖0010
                wall_position(Brick_0010, i, j);
                break;
            case 14:
                // //生成一块红砖砖0001
                wall_position(Brick_0001, i, j);
                break;


            case 15:
                //基地
                wall_position(home_object, i, j);
                break;
             
            default :
                break;
        }
    }

    //----生成砖块的位置---
    private void wall_position(GameObject Wall_object,int i, int j)
    {   //地图片上每个砖块的位置
        float temp_x = (-6f) + j;
        float temp_y = (6f) - i;
        Vector3 temp_p = new Vector3(temp_x, temp_y, 0); //生成一个向量存坐标
        GameObject temp_wall = (GameObject)Instantiate(Wall_object, temp_p, Quaternion.identity); //生成砖块
        temp_wall.transform.SetParent(all_block.transform);//所有砖块加载到父亲内
    }



}//class
