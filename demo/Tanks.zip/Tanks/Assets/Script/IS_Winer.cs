﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class IS_Winer : MonoBehaviour {

    private bool IS_WIN;
	void Update () {
        if (IS_WIN == true) { return; }
        int tempInt =ManageClass.enemyTypeCount_A+ManageClass.enemyTypeCount_B+ManageClass.enemyTypeCount_C+ManageClass.enemyTypeCount_D;
        if (tempInt==20)
        {
          //过关
            Invoke("nextLeve", 5f);
            IS_WIN = true;
        }
	}

    void nextLeve() {
        if(ManageClass.IS_GAMEOVER==false){
            SceneManager.LoadScene("ShowScore");
        }
        else if(ManageClass.LeveCount>=ManageClass.MaxLeveCount){
            //如果是最后一关
            SceneManager.LoadScene("ShowScore");
        }
       
    }
}
