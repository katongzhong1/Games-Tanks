﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class EnemyIconCode : MonoBehaviour
{
  //  private Image enemy_icon,Player_Icon_Object ,Leve_Icon_object;
    private Image enemy_icon;
    private Image myImage;
    private List<Image> enemyIcon_list = new List<Image>();
    public Text playerCountText, LeveCountText;
    public static EnemyIconCode _enemyIconScript;
    private Text DelEnemyScoreText;
    void Awake() {
        _enemyIconScript = this;
    }
    void Start()
    {
       enemy_icon = Resources.Load("ICON/enemy_icon", typeof(Image)) as Image; //加载Enemy图标对象
       DelEnemyScoreText = Resources.Load("DelEnemyScoreText/DelEnemyScore", typeof(Text)) as Text;

     //   Player_Icon_Object = Resources.Load("ICON/IP_ICON", typeof(Image)) as Image; //加载player图标对象
      //  Leve_Icon_object = Resources.Load("ICON/flag_icon", typeof(Image)) as Image; //加载关数图标对象
      
       for (var i = 0; i < 10; i++)
        {
            for (var j = 0; j < 2; j++) {
                Image tempEnemyIcon = (Image)Instantiate(enemy_icon, new Vector3(240f+j*16f, 168f-i*16f, 0), Quaternion.identity);
                tempEnemyIcon.transform.SetParent(this.transform.GetChild(3).transform, false);
                enemyIcon_list.Add(tempEnemyIcon);
            }
          
        }
       Destroy(enemyIcon_list[enemyIcon_list.Count - 1].gameObject);
       enemyIcon_list.RemoveAt(enemyIcon_list.Count - 1);
        //加载主角机数到场景
      // Image tempPlayerIconObject = (Image)Instantiate(Player_Icon_Object, new Vector3(337f,-51f,0), Quaternion.identity);
      // tempPlayerIconObject.transform.SetParent(this.transform, false);
       //加载关数到场景
     //  Image tempLeveIconObject = (Image)Instantiate(Leve_Icon_object, new Vector3(340f,-188f,0), Quaternion.identity);
     //  tempLeveIconObject.transform.SetParent(this.transform, false);
       playerCountText.text = ManageClass.PlayerCount + "";//显示主机数
    }
    //删除敌机泛型的最后一个对象
    public void Del_last_List()
    {
        if (enemyIcon_list.Count > 0) {
            Destroy(enemyIcon_list[enemyIcon_list.Count - 1].gameObject);
            enemyIcon_list.RemoveAt(enemyIcon_list.Count - 1);

        }
    }

    //设置主机数
    public void setPlayerCount() {
       playerCountText.text = ManageClass.PlayerCount + "";

    }
    //设置关数
    public void setLeveCount() {
        LeveCountText.text = ManageClass.LeveCount + "";
    }

    //从下向上升起GAME OVER 字
    public void setGameOver() {
        this.transform.GetChild(0).gameObject.SetActive(true);
        Invoke("waitForShowScoreWindows", 5f);

    }
    //设置删除敌机的分数显示
    public void setDelEnemyScore(int tempScore,Transform tran) {
        Text tempText = (Text)Instantiate(DelEnemyScoreText,tran);//生成一个分数
        tempText.transform.SetParent(this.transform, false);//设置父对象为CANVAS
        tempText.text = tempScore + "";//显示的分数
        tempText.transform.position = tran.position;//坐标为敌机的坐标
        ManageClass.playerScore += tempScore; //更新主角分数
        //更新最高分
        if (ManageClass.playerScore > ManageClass.heightScore)
        {
            ManageClass.heightScore = ManageClass.playerScore;
        }
        Destroy(tempText.gameObject, 1f);
    }


    private void waitForShowScoreWindows() {
        SceneManager.LoadScene("ShowScore"); //显示计分介面
    }
}