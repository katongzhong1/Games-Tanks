﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fourBrick : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        is_delAll();
	}

    //判断子砖数是不是0，如果是就删除整个砖
    public void is_delAll()
    {
        if (this.transform.childCount == 0)
        {

            Destroy(this.gameObject);

        }


    }

 
}
