﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Brick_wall : MonoBehaviour {
    //红砖半块砖的类型
    private enum Brick_Type_enum
    {
        Brick_0011=0,
        Brick_1100=1,
        Brick_0101=2,
        Brick_1010=3,

        Brick_1000 = 4,
        Brick_0100 = 5,
        Brick_0010 = 6,
        Brick_0001 = 7
    }
    public int Brick_Type ;
	void Awake() {
        //一开始删除为0的子对象小砖块
        switch (Brick_Type)
        {  case (int)Brick_Type_enum.Brick_0011:
                Destroy(this.gameObject.transform.GetChild(0).gameObject);
                Destroy(this.gameObject.transform.GetChild(1).gameObject);
                break;
        case (int)Brick_Type_enum.Brick_1100:
                Destroy(this.gameObject.transform.GetChild(2).gameObject);
                Destroy(this.gameObject.transform.GetChild(3).gameObject);
                break;
        case (int)Brick_Type_enum.Brick_0101:
                Destroy(this.gameObject.transform.GetChild(0).gameObject);
                Destroy(this.gameObject.transform.GetChild(2).gameObject);
                break;
        case (int)Brick_Type_enum.Brick_1010:
                Destroy(this.gameObject.transform.GetChild(1).gameObject);
                Destroy(this.gameObject.transform.GetChild(3).gameObject);
                break;
                //以下是一块小砖
        case (int)Brick_Type_enum.Brick_0010:
                Destroy(this.gameObject.transform.GetChild(0).gameObject);
                Destroy(this.gameObject.transform.GetChild(1).gameObject);
                Destroy(this.gameObject.transform.GetChild(3).gameObject);
                break;
        case (int)Brick_Type_enum.Brick_0001:
                Destroy(this.gameObject.transform.GetChild(0).gameObject);
                Destroy(this.gameObject.transform.GetChild(1).gameObject);
                Destroy(this.gameObject.transform.GetChild(2).gameObject);
                break;


            default:
                break;
        }
	}
         
    void Update() {
        is_delAll();
      
    }
    //判断子砖数是不是0，如果是就删除整个砖
    public  void is_delAll()  {
        if (this.transform.childCount == 0)
        {
           
            Destroy(this.gameObject);
        }
        

       
    }

}
