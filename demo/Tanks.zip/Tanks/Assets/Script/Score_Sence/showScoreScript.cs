﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class showScoreScript : MonoBehaviour {
    private Text oneEnemyScore,one_enemy_count,twoEnemyScore,two_enemy_count,threeEnemyScore,three_enemy_count,four_EnemyScore,four_enemy_count ,allEnemyCount;
    private bool IE_OFF;
    private float logoTime = 0.3f;

	void Start () {
        this.transform.GetChild(0).transform.GetChild(0).GetComponent<Text>().text = ManageClass.heightScore +""; //最高分
        this.transform.GetChild(1).transform.GetChild(0).GetComponent<Text>().text = ManageClass.LeveCount + ""; //关数
        this.transform.GetChild(2).transform.GetChild(0).GetComponent<Text>().text = ManageClass.playerScore + ""; //关数
        //取得几行的敌机分数和敌机数量
        oneEnemyScore = this.transform.GetChild(3).transform.GetChild(0).GetComponent<Text>();
        one_enemy_count = this.transform.GetChild(3).transform.GetChild(2).GetComponent<Text>();

        twoEnemyScore = this.transform.GetChild(4).transform.GetChild(0).GetComponent<Text>();
        two_enemy_count = this.transform.GetChild(4).transform.GetChild(2).GetComponent<Text>();

        threeEnemyScore = this.transform.GetChild(5).transform.GetChild(0).GetComponent<Text>();
        three_enemy_count = this.transform.GetChild(5).transform.GetChild(2).GetComponent<Text>();

        four_EnemyScore = this.transform.GetChild(6).transform.GetChild(0).GetComponent<Text>();
        four_enemy_count = this.transform.GetChild(6).transform.GetChild(2).GetComponent<Text>();
        //总敌机数
        allEnemyCount = this.transform.GetChild(7).transform.GetChild(1).GetComponent<Text>();
        

        StartCoroutine(ShowScore()); //启动协程
	}

    IEnumerator ShowScore()
    {
        if (IE_OFF == true) { yield return 0; }
        //一到四行的数值
        if (ManageClass.enemyTypeCount_A > 0) {
            for (var i = 0; i < ManageClass.enemyTypeCount_A; i++)
            {
                oneEnemyScore.text = (i * 100 + 100) + "";
                one_enemy_count.text = (i + 1) + "";
                yield return new WaitForSeconds(logoTime);
            }
           
        }
        if (ManageClass.enemyTypeCount_B > 0)
        {
            for (var i = 0; i < ManageClass.enemyTypeCount_B; i++)
            {
                twoEnemyScore.text = (i * 100 + 100) + "";
                two_enemy_count.text = (i + 1) + "";
                yield return new WaitForSeconds(logoTime);
            }

        }
        if (ManageClass.enemyTypeCount_C > 0)
        {
            for (var i = 0; i < ManageClass.enemyTypeCount_C; i++)
            {
               threeEnemyScore.text = (i * 100 + 100) + "";
                three_enemy_count.text = (i + 1) + "";
                yield return new WaitForSeconds(logoTime);
            }

        }
        if (ManageClass.enemyTypeCount_D > 0)
        {
            for (var i = 0; i < ManageClass.enemyTypeCount_D; i++)
            {
                four_EnemyScore.text = (i * 100 + 100) + "";
                four_enemy_count.text = (i + 1) + "";
                yield return new WaitForSeconds(logoTime);
            }

        }
        //总敌机数
        int tempCount = ManageClass.enemyTypeCount_A + ManageClass.enemyTypeCount_B + ManageClass.enemyTypeCount_C + ManageClass.enemyTypeCount_D;

            allEnemyCount.text = tempCount + "";
           
            yield return new WaitForSeconds(3f);
            //如果游戏结束
            if (ManageClass.IS_GAMEOVER == true)
            {
                SceneManager.LoadScene("GameOverLast");//加载GameOverLast介面
                ManageClass.restGame(); //重置游戏
            }
            else { 
            //如果是过关了
                //----------过关关数加一------------
                ManageClass.LeveCount += 1; 

                switch(ManageClass.LeveCount){
                    case 2:
                        //进入第二关
                          ManageClass.nextLeveSet();//进关的选项重置
                          SceneManager.LoadScene("LEVE2");//加载leve2介面
                          
                        break;
                    case 3:
                       SceneManager.LoadScene("GameOverLast");//加载GameOverLast介面
                       ManageClass.restGame(); //重置游戏
                        break;
                }
            }
            IE_OFF = true;
            yield return 0;
    }
	
}
