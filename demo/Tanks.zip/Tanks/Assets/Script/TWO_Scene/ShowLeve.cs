﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class ShowLeve : MonoBehaviour {

    private int leveCount=1;
    private int maxLeve_count = ManageClass.MaxLeveCount;//最大关数
	void Start () {
		
	}
	
	
	void Update () {

        //增加关数
		if(Input.GetKeyDown(KeyCode.S)){
            if (leveCount < maxLeve_count) {
                //当前关数小于最大关数时
                leveCount += 1;

            }

        }
        //减少关数
      if (Input.GetKeyDown(KeyCode.W)) { 
            if (leveCount > 1) {
                //当前关数小于最大关数时
                leveCount -= 1;

            }
        }

      this.gameObject.GetComponent<Text>().text = leveCount + "";//显示关数
        //加载关数开始游戏
      if (Input.GetKeyDown(KeyCode.Space)) {
          ManageClass.LeveCount = leveCount;
          if (leveCount ==1) {
              SceneManager.LoadScene("game_start");
          }
          else if (leveCount == 2) {
              SceneManager.LoadScene("LEVE2");
          }
        
      }
	}
}
