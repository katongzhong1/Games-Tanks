﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateTake : MonoBehaviour {

     private GameObject Player_object,Bore_Object;
     private GameObject[] enemyArry = new GameObject[8];//

     private Vector3[] OutOfPosition = new Vector3[3];//敌机出场位置
     private Vector3 playerOutPosition = new Vector3(-1.448073f, -6.029788f, 10f);//主角出场位置
   
     private GameObject[,] OutTakeArry= new GameObject[2,20];

     private GameObject[] Reward_Arry = new GameObject[6];//奖励品的数组
	void Awake () {
        //----------敌机出场位置-------
        OutOfPosition[0] = new Vector3(-6f, 6f, 10f); //左边 
        OutOfPosition[1] = new Vector3(0f, 6f, 10f);//中间
        OutOfPosition[2] = new Vector3(6f, 6f, 10f);//右边


        // -----------加载坦克对象----------
        logoTake();
          // -----------加载奖励品对象----------
        logoReward();



        //----------生成出场坦克数组------------
        CreateOutTakeArry();
        //----------出场星星------------
        Bore_Object = (GameObject)Resources.Load("Other/Bore"); 

        //------------生成主角----------
        GameObject Temp_Bore_object = (GameObject)Instantiate(Bore_Object, playerOutPosition, Quaternion.identity);
        Temp_Bore_object.SendMessage("createTake",Player_object);




        //------------为每个关卡，生成不同的敌机坦克----------
        if (ManageClass.LeveCount == 1) {

            //---------生成第一关第一个敌机-----------
            GameObject Temp_Bore_object2 = (GameObject)Instantiate(Bore_Object, OutOfPosition[1], Quaternion.identity);
            
            // 初始化出场敌机泛型
            initTakeList();
            Temp_Bore_object2.SendMessage("createTake", ManageClass.Take_List[0]);  //----------出场星星------------
            ManageClass.Take_List.RemoveAt(0);//每出一个敌机在敌机总泛型内删除其对应位置
            EnemyIconCode._enemyIconScript.Del_last_List();//删除和敌机图标
            StartCoroutine(ReturnCreateTake());//启动协程，每3秒生成一个敌机
        }
        else if (ManageClass.LeveCount == 2)
        {
            //-----------生成第二关第一个敌机------------
            GameObject Temp_Bore_object2 = (GameObject)Instantiate(Bore_Object, OutOfPosition[1], Quaternion.identity);
            // 初始化出场敌机泛型
            initTakeList();
            Temp_Bore_object2.SendMessage("createTake", ManageClass.Take_List[0]);
            ManageClass.Take_List.RemoveAt(0);
            EnemyIconCode._enemyIconScript.Del_last_List();//删除和敌机图标
            StartCoroutine(ReturnCreateTake());
        }

       
	}

    /// <summary>
    /// 加载坦克对象
    /// </summary>
    private void logoTake() {
        Player_object = (GameObject)Resources.Load("playerOne"); //主角Enemy
        enemyArry[0] = (GameObject)Resources.Load("Enemy/enemy_A1"); //主角Enemy
        enemyArry[1] = (GameObject)Resources.Load("Enemy/enemy_A2"); //主角Enemy
        enemyArry[2] = (GameObject)Resources.Load("Enemy/enemy_B1"); //主角Enemy
        enemyArry[3] = (GameObject)Resources.Load("Enemy/enemy_B2"); //主角Enemy
        enemyArry[4] = (GameObject)Resources.Load("Enemy/enemy_C1"); //主角Enemy
        enemyArry[5] = (GameObject)Resources.Load("Enemy/enemy_C2"); //主角Enemy
        enemyArry[6] = (GameObject)Resources.Load("Enemy/enemy_D1"); //主角Enemy
        enemyArry[7] = (GameObject)Resources.Load("Enemy/enemy_D2"); //主角Enemy
    }

    /// <summary>
    /// 加载奖励品
    /// </summary>
    private void logoReward() {
        Reward_Arry[0] = (GameObject)Resources.Load("Reward/add_p1"); //奖励品add_p1加一只机
        Reward_Arry[1] = (GameObject)Resources.Load("Reward/Boom_bomb"); //奖励品Boom_bomb炸弹
        Reward_Arry[2] = (GameObject)Resources.Load("Reward/shield_Reward"); //奖励品shield_Reward防护罩

        Reward_Arry[3] = (GameObject)Resources.Load("Reward/shovel"); //奖励品shovel铁铲
        Reward_Arry[4] = (GameObject)Resources.Load("Reward/starts"); //奖励品starts星星
        Reward_Arry[5] = (GameObject)Resources.Load("Reward/stop_Boom"); //奖励品stop_Boom定时炸弹

    
    }



    /// <summary>
    /// 协程产生坦克
    /// </summary>
    /// <returns></returns>
    IEnumerator ReturnCreateTake() {

        while (true) {
            if (ManageClass.OutTakeCount > 0 && ManageClass.Take_List.Count>0) {
                yield return new  WaitForSeconds(3.0f);

                int tempCount = Random.Range(0, 3);
                //生成出场星星
                GameObject Temp_Bore_object2 = (GameObject)Instantiate(Bore_Object, OutOfPosition[tempCount], Quaternion.identity);
                Temp_Bore_object2.SendMessage("createTake", ManageClass.Take_List[0]);//生成敌机
                ManageClass.Take_List.RemoveAt(0);//删除已出场敌机在，总敌机组内的位置对象
                EnemyIconCode._enemyIconScript.Del_last_List();//删除和敌机图标
                
           ManageClass.OutTakeCount -= 1;//将出场的敌机数减去1
           CreateRewardObject(); //-----生成奖励品    ----------
                
            }
            yield return 0;
        }

      
    
    }


    /// <summary>
    /// 生成出场坦克数组
    /// </summary>
    void CreateOutTakeArry() {
        OutTakeArry[0,0] = enemyArry[0];
        OutTakeArry[0,1] = enemyArry[0];
        OutTakeArry[0, 2] = enemyArry[0];
        OutTakeArry[0, 3] = enemyArry[1];
        OutTakeArry[0, 4] = enemyArry[0];
        OutTakeArry[0, 5] = enemyArry[0];
        OutTakeArry[0, 6] = enemyArry[0];
        OutTakeArry[0, 7] = enemyArry[0];
        OutTakeArry[0, 8] = enemyArry[0];
        OutTakeArry[0, 9] = enemyArry[0];
        OutTakeArry[0, 10] = enemyArry[0];

        OutTakeArry[0, 11] = enemyArry[1];
        OutTakeArry[0, 12] = enemyArry[0];
        OutTakeArry[0, 13] = enemyArry[0];
        OutTakeArry[0, 14] = enemyArry[0];
        OutTakeArry[0, 15] = enemyArry[0];
        OutTakeArry[0, 16] = enemyArry[1];
        OutTakeArry[0, 17] = enemyArry[0];
        OutTakeArry[0, 18] = enemyArry[2];
        OutTakeArry[0, 19] = enemyArry[2];




        //-------leve2-------
        OutTakeArry[1, 0] = enemyArry[6];
        OutTakeArry[1, 1] = enemyArry[6];
        OutTakeArry[1, 2] = enemyArry[2];
        OutTakeArry[1, 3] = enemyArry[3];
        OutTakeArry[1, 4] = enemyArry[2];
        OutTakeArry[1, 5] = enemyArry[2];
        OutTakeArry[1, 6] = enemyArry[0];
        OutTakeArry[1, 7] = enemyArry[0];
        OutTakeArry[1, 8] = enemyArry[0];
        OutTakeArry[1, 9] = enemyArry[0];
        OutTakeArry[1, 10] = enemyArry[1];

        OutTakeArry[1, 11] = enemyArry[1];
        OutTakeArry[1, 12] = enemyArry[0];
        OutTakeArry[1, 13] = enemyArry[0];
        OutTakeArry[1, 14] = enemyArry[0];
        OutTakeArry[1, 15] = enemyArry[0];
        OutTakeArry[1, 16] = enemyArry[0];
        OutTakeArry[1, 17] = enemyArry[1];
        OutTakeArry[1, 18] = enemyArry[0];
        OutTakeArry[1, 19] = enemyArry[0];
        
    
    }

    /// <summary>
    /// 初始化出场敌机泛型
    /// </summary>
    void initTakeList()
    {
        if (ManageClass.LeveCount == 1) {
          
                for (var j = 0; j < 20; j++) {
                    ManageClass.Take_List.Add(OutTakeArry[0, j]);
                }
            
        }
        else if (ManageClass.LeveCount == 2) {
            
                for (var j = 0; j < 20; j++)
                {
                    ManageClass.Take_List.Add(OutTakeArry[1, j]);
                }
           
        }
      

    }



    /// <summary>
    /// 生成奖励品
    /// </summary>
    void CreateRewardObject() {
        //出现奖励品时间
        if (ManageClass.Take_List.Count == 13 ) {
            CreatRandomLcotionReward(); //出现奖励品
        }
        else if (ManageClass.Take_List.Count == 7)
        {
            CreatRandomLcotionReward(); //出现奖励品
        }
        else if (ManageClass.Take_List.Count == 1)
        {
            CreatRandomLcotionReward(); //出现奖励品
        }
    
    }

    /// <summary>
    /// 生成随机位置放奖励品
    /// </summary>
    void CreatRandomLcotionReward() {
        int tempInt = Random.Range(0, 5);
        float tempX = Random.Range(-6, 6);
        float tempY = Random.Range(6, -6);
        GameObject temp_Reward_object = (GameObject)Instantiate(Reward_Arry[tempInt], new Vector3(tempX, tempY, 0), Quaternion.identity);
    }








}
