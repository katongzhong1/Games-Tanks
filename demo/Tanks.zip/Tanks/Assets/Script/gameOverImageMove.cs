﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gameOverImageMove : MonoBehaviour {

	// Use this for initialization
	void Start () {
		if(this.gameObject.activeInHierarchy==true){
            Invoke("setTimeDel", 5f);
        }
	}

    private void setTimeDel() {
        Destroy(this.gameObject);
    }
}
