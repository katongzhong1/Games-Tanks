﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Bullet_Move : MonoBehaviour {
    private float MoveSpeed = 8f;
    private Rigidbody2D rb;
    public bool IS_PLAYER_BULLET = false;
    private GameObject player_object; //主角对象
    public GameObject enemy_object; //敌机对象
    private GameObject small_Boom_Object, Big_Boom_Object;
    private GameObject Bore_Object, Player_object22;
    private Vector3 playerOutPosition = new Vector3(-1.448073f, -6.029788f, 10f);//主角出场位置
   


	void Start () {
        //为子弹添加一个向前的力
        rb = GetComponent<Rigidbody2D>();
        Vector3 v3 = transform.up.normalized;
        rb.velocity = v3 * MoveSpeed;

        if (IS_PLAYER_BULLET==true) { //如果是主角子弹，
            player_object = GameObject.FindGameObjectWithTag("Player"); //取得主角对象
        }
        //BOOM
        small_Boom_Object = (GameObject)Resources.Load("Block/Boom/Small_Boom");
        Big_Boom_Object = (GameObject)Resources.Load("Block/Boom/Big_Boom");

        Bore_Object = (GameObject)Resources.Load("Other/Bore"); //出场星星
        Player_object22 = (GameObject)Resources.Load("playerOne"); //加载主角
      
	}
  

    /// <summary>
    ///当子弹注销，就要更新主角的，现在子弹数
    /// </summary>
    private void updateNowButtletCount() {
        if (player_object != null)
        { //如果主角还在场上
            int tempCount = player_object.GetComponent<PlayerControl>().nowButtletCount;//取得现在主角的子弹数
            if (tempCount > 0)
            {
                player_object.GetComponent<PlayerControl>().nowButtletCount -= 1; //主角现在的子弹数减去一
            }

        }
    }
    /// <summary>
    /// 当子弹注销，就要更新敌机的，现在子弹数
    /// </summary>
    private void updateNowButtletCountEnemy() {
        //敌机对象不为空
        if (enemy_object != null) {
            enemy_object.GetComponent<EnemyControl>().setCreateBulllet();//敌机制造子弹开关打开
        }
       
    }

    /// <summary>
    /// 碰撞检测
    /// </summary>
    /// <param name="Other"></param>
    void OnTriggerEnter2D(Collider2D Other)
    {

        //#####################主角子弹##########################
        if (IS_PLAYER_BULLET == true)
        {
            switch (Other.tag) { 

                case "SmallBrick":
                    //----------红砖---------------
                  //  GameObject tempBrickObject = Other.gameObject.transform.parent.gameObject;
                   // tempBrickObject.SendMessage("is_delAll",Other.gameObject);
                   Destroy(this.gameObject);
                   Destroy(Other.gameObject);
                     
                      //当子弹注销，就要更新主角的，现在子弹数
                     updateNowButtletCount();
                     Instantiate(small_Boom_Object, this.transform.position,Quaternion.identity);
                     break;
                case "smallGrid":
                    //----------钻石砖---------------
                    Destroy(this.gameObject);
                    //当子弹注销，就要更新主角的，现在子弹数
                    updateNowButtletCount();
                    Instantiate(small_Boom_Object, this.transform.position,Quaternion.identity);
                    break;




                case "Bound":
                case "home":
                    //---------边界和基地---------------
                    Destroy(this.gameObject);
                    updateNowButtletCount();
                    Instantiate(small_Boom_Object, this.transform.position, Quaternion.identity);
                    break;
                case "enemy":
                    Destroy(this.gameObject);
                  //  Destroy(Other.gameObject);
                    Other.SendMessage("Die");
                    updateNowButtletCount();
                   // Instantiate(Big_Boom_Object, Other.transform.position, Quaternion.identity);//加入boom
                    ManageClass.OutTakeCount += 1;
                  
                    break;
                case "enemyBullet":
                    Destroy(this.gameObject);
                    Destroy(Other.gameObject);
                    updateNowButtletCount();
                    //当子弹注销，就要更新主角的，现在子弹数
                    updateNowButtletCountEnemy();
                   // Instantiate(small_Boom_Object, this.transform.position, Quaternion.identity);//加入boom
                  
                    break;

            }


          
        }

        //########################敌机子弹#######################
        else
        {
            switch (Other.tag)
            {
                case "SmallBrick":
                    //----------红砖---------------
                    Destroy(Other.gameObject);
                   // GameObject tempBrickObject = Other.gameObject.transform.parent.gameObject;
                   // tempBrickObject.SendMessage("is_delAll");
                    Destroy(this.gameObject);
                   // Destroy(Other.gameObject);
                    //当子弹注销，就要更新主角的，现在子弹数
                    updateNowButtletCountEnemy();
                    Instantiate(small_Boom_Object, this.transform.position, Quaternion.identity);
                    break;
                case "smallGrid":
                    //----------钻石砖---------------
                    Destroy(this.gameObject);
                    //当子弹注销，就要更新主角的，现在子弹数
                    updateNowButtletCountEnemy();
                    Instantiate(small_Boom_Object, this.transform.position, Quaternion.identity);
                    break;




                case "Bound":
                case "home":
                    //---------边界和基地---------------
                    Destroy(this.gameObject);
                    //当子弹注销，就要更新主角的，现在子弹数
                    updateNowButtletCountEnemy();
                    Instantiate(small_Boom_Object, this.transform.position, Quaternion.identity);
                    break;
                case "Player":
                    //-----------主角------------------
                    Destroy(this.gameObject);//注销子弹对象

                    //当子弹注销，就要更新主角的，现在子弹数
                    updateNowButtletCountEnemy();   //当子弹注销，就要更新敌机的，现在子弹数

                    //----------判断防护罩是不是隐藏----------
                    if (Other.transform.GetChild(0).gameObject.activeInHierarchy == true) { return; }


                    //--------如果主角当前4级状态，那么就下落致1级，后返回--------
                    if (Other.GetComponent<PlayerControl>().LV==4) {
                        Other.SendMessage("setLV");  //如果主角是4级与子弹碰撞，那么就下落到1级
                        return;
                    }
                    Destroy(Other.gameObject);
                    Instantiate(Big_Boom_Object, Other.transform.position, Quaternion.identity);//加入boom
                    ManageClass.PlayerCount -= 1; //主角机数减去1

                    if (ManageClass.PlayerCount >= 0)
                    {
                        //生成主角
                        GameObject Temp_Bore_object = (GameObject)Instantiate(Bore_Object, playerOutPosition, Quaternion.identity);
                        Temp_Bore_object.SendMessage("createTake", Player_object22);
                        EnemyIconCode._enemyIconScript.setPlayerCount(); //设置主角图标数
                    }
                    else {
                        //游戏结束
                        EnemyIconCode._enemyIconScript.setGameOver();
                        ManageClass.IS_GAMEOVER = true;
                      
                    }
                    break;

            }
        }

    }//OnTriggerEnter2D



}
