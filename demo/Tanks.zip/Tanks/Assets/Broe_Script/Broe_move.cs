﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Broe_move : MonoBehaviour {

    public GameObject Take_Object;
	void Start () {
		
	}
	
    public void Die()
    {
        Destroy(this.gameObject);
        //如果主角
        if (Take_Object.tag == "Player")
        {
            Instantiate(Take_Object, this.transform.position, Quaternion.identity);//星星过后，生成坦克
      
        }
        else
        {//----------敌机，将所有敌机加入到一个父中-----------
            GameObject tmepEnemyObject = (GameObject)Instantiate(Take_Object, this.transform.position, Quaternion.identity);//星星过后，生成坦克
            GameObject tmepAllEnemyArry = GameObject.FindGameObjectWithTag("allEnemyTag"); //取得敌机父的对象
            tmepEnemyObject.transform.SetParent(tmepAllEnemyArry.transform, false);//设置父对象
        }
      
    }
    //生成坦克
    public void createTake(GameObject tempTakeObject) {
        Take_Object = tempTakeObject;
     

       
    }

}
